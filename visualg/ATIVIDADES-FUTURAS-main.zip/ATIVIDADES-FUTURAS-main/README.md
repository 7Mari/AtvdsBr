# ATIVIDADES-FUTURAS
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <time.h>
#include <ctype.h>

int main () {
	setlocale(LC_ALL, "portuguese");
	
	int salario;
	int quantidadefilhos;
	int opcao;
	int mediafilhos;
	float mediasalario, somasalario = 0, contadorsalario = 0;
	int menorsalario = 99999 ,maiorsalario ,totalfamilia;
	int contadoropcao ,somaopcao;
	int contadorfilhos , somafilhos;
	
	
	
	do {
		printf("--PESQUISA DE HABITANTES-- \n\n");
		printf("1- Adicionar familia \n");
		printf("2- Sair e exibir resultados \n");
		printf("Digite o número de sua preferencia:\n ");
		scanf("%d" ,&opcao);
		switch (opcao) {
			case 1:
				printf("Informe seu salário \n: ");
				scanf("%d" ,&salario);
	
				printf("Informe a quantidade de filhos \n: ");
				scanf("%d" ,&quantidadefilhos);	
				
				contadoropcao++;
				somaopcao += opcao;
				
				contadorfilhos++;
				somafilhos += quantidadefilhos;
				
				contadorsalario++;
				somasalario += salario;
				
				maiorsalario = maiorsalario > salario ? maiorsalario : salario;
				menorsalario = menorsalario < salario ? menorsalario : salario;
				
				system ("cls || clear");
				
				break;
				
			case 2:
				
				mediafilhos = somafilhos / contadorfilhos;
				mediasalario = somasalario / contadorsalario;
				totalfamilia = contadoropcao;
				
				printf("Média de filhos: %d \n" ,mediafilhos);
				printf("Média dos salários: %.2f \n" ,mediasalario);
				printf("Maior Salário: %d \n" ,maiorsalario);
				printf("Menor Salário: %d \n" ,menorsalario);
				printf("Total de familias adicionadas: %d \n" ,totalfamilia);
			
			break;
			default:
				printf("Opção inválida!");
				//sleep(3);
				system("cls || clear");
		}
				
	
	
	}while (opcao != 2);
	
	
	
	return 0;
}
